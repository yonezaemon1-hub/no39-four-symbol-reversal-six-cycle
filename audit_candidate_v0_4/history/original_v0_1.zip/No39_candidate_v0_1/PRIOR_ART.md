# No.39 scoped prior-art check — 25 October 2026

## Decision

NOVELTY: INCONCLUSIVE. REFERENCES: PARTIAL.

The explicit, sharp four-consecutive-symbol sufficiency statement is a
candidate residual. The broader mechanisms and the eventual-detection
dichotomy are established context or direct consequences and are not claimed
as discoveries. No claim of exhaustive coverage is made.

## Primary texts actually inspected

| Source | Access and relevant location | Consequence for this candidate |
| --- | --- | --- |
| Arola-Fernandez--Lacasa (2023), arXiv:2303.11868 | PDF, Section III.A, pp.4-5; example `0010110010` on p.5 | The binary word-length lower bound and short asymmetric symbolic examples are known. |
| Finucane--Tamuz--Yaari (2014), author-hosted scenery.pdf | PDF, Introduction and Theorem 1.2; Appendix A theorem argument | Distinct Fourier coefficients give reconstruction. The nonresonant eventual-detection claim follows from this theorem. |
| Bauer--Seifert--van der Meer (2025), arXiv:2412.15642v2 | Full HTML, especially Section 3.2.2, equations (30)-(33) | Periodic-sampling ambiguity between generators and equilibrium/nonequilibrium is established. |

URLs and bibliographic details are in PROOF.md. Only relevant passages were
analyzed; no full independent re-audit of these papers is claimed.

## Closest earlier chain not yet fully inspected

Matzinger--Lember (2006), *Reconstruction of periodic sceneries seen along a
random walk*, SPA 116, 1584-1599, and Howard's earlier scenery work were located
through publisher/index records and the 2014 primary paper's references.
The attempted 2006 manuscript retrieval at CiteSeerX returned HTTP 403.
Its full theorem comparison is incomplete. The 2014 author's PDF states and
proves the spectral reconstructivity theorem needed for the known-consequence
classification above; that does not establish that the earlier literature
lacks an explicit length-four result.

## Search coverage and limits

The initial searches covered binary hidden Markov time reversal, irreversibility
on colored cycles, random-walk scenery reconstruction, stroboscopic Markov
sampling, and four-point/length-four reversal statistics. Follow-ups used
`001011`, `0011`, `six-state`, `circulant`, `four-point`, and `sampling` in
combinations with time reversal or irreversibility. Two search engines were
used. Exact-phrase searches were frequently sparse or irrelevant.

The search established that the general topic and all-length distinguishability
are occupied. It did not establish historical novelty for the explicit witness
formula. Unread texts, alternate formulations, and immediate consequences of
other finite-HMM results remain possible. A final novelty statement should
stay INCONCLUSIVE unless that comparison is materially extended.

## What an adversarial audit should try to break

1. Verify the clockwise sign convention in the six Fourier eigenvalues and
   in p(0011)-p(1100).
2. Expand the two probabilities directly, independently of exact_algebra.py.
3. Check the Bernstein certificate and the split at r^2=3/4.
4. Try to find a nonresonant zero for the four-word difference.
5. Check that no nonstationary, heterogeneous-rate, unequal-spacing,
   finite-sample, or general-HMM conclusion has been silently added.
6. Search the scenery and HMM literature for this specific consecutive
   length-four witness before considering a priority claim.

This package has no external audit report. Two implementations written in the
same assistant session are internal cross-checks, not independent peer review.
